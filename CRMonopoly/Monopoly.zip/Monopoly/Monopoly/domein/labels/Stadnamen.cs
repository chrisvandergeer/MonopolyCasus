﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monopoly.domein.labels
{
    class Stadnamen
    {
        public static readonly string AMSTERDAM = "Amsterdam";
        public static readonly string ARNHEM = "Arnhem";
        public static readonly string DEN_HAAG = "DenHaag";
        public static readonly string GRONINGEN = "Groningen";
        public static readonly string HAARLEM = "Haarlem";
        public static readonly string ONS_DORP = "OnsDorp";
        public static readonly string ROTTERDAM = "Rotterdam";
        public static readonly string UTRECHT = "Utrecht";
    }
}
