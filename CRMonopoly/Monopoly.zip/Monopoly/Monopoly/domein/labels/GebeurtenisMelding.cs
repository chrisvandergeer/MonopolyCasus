﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monopoly.domein.labels
{
    public class GebeurtenisMelding
    {
        public static readonly string OP_START = "U komt op start en ontvangt ƒ 400,00";
        public static readonly string LANGS_START = "U komt op start en ontvangt ƒ 200,00";
        public static readonly string INKOMSTENBELASTING = "Betaal ƒ 200,00 inkomsten belasting";
    }
}
